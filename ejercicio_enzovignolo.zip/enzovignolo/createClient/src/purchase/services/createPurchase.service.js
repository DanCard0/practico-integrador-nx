const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');

const PURCHASE_TABLE = config.get('PURCHASE_TABLE')
const createPurchase = async (purchaseInfo) => {
    const purchase = await dynamo.putItem({ TableName: PURCHASE_TABLE, Item: purchaseInfo });
    return purchase;
}

module.exports = { createPurchase };