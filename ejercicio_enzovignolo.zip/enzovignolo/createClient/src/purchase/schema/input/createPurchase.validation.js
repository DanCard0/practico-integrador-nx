const { InputValidation } = require('ebased/schema/inputValidation')
class CreatePurchsaeValidation extends InputValidation {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.CREATE_CLIENT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                products: {
                    type: [{
                        name: { type: String, required: true },
                        price: { type: Number, required: true }
                    }]
                },
                dni: { type: String, required: true },
            },
        })
    }
};

module.exports = { CreatePurchsaeValidation };