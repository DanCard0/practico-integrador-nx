const CREDITCARD_DISCOUNTS = {
    "CLASSIC": 0.08,
    "GOLD": 0.12
}
const applyDiscount = (clientInfo, products) => {
    const cardType = clientInfo.creditCard.type;
    const discount = CREDITCARD_DISCOUNTS[cardType] || 1;
    const finalProducts = products.map((product) => {
        return { ...product, finalPrice: (product.price - product.price * discount) }
    })
    return finalProducts
}

module.exports = applyDiscount;