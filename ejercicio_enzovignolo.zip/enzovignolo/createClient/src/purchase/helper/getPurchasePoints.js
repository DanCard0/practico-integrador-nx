const getPurchasePoints = (products) => {
    if (!Array.isArray(products)) throw new Error('only array')
    const finalTotal = products.reduce((acc, curr) => acc + curr.finalPrice, 0);
    const totalPoints = Math.floor(finalTotal / 200);
    return totalPoints;
}

module.exports = getPurchasePoints;