const { CreatePurchsaeValidation } = require("../schema/input/createPurchase.validation");
const { getClient } = require("../../client/services/getClient.service");
const { updateClient } = require("../../client/services/updateClient.service");

const { ErrorHandled } = require("ebased/util/error");
const { createPurchase } = require("../services/createPurchase.service");
const { v4: uuidv4 } = require('uuid');
const applyDiscount = require("../helper/getClientDiscount");
const getPurchasePoints = require("../helper/getPurchasePoints");

module.exports = async (commandPayload, commandMeta) => {
    //validate input : compras con array de objetos c/ nomb prod y precio, dni del comprador
    const rawPurchase = new CreatePurchsaeValidation(commandPayload, commandMeta)
    // find user and check if is active
    const { dni, products } = commandPayload;
    const client = await getClient(dni);
    if (!client) throw new ErrorHandled('Client not found', { status: 404, layer: 'DOMAIN' });
    if (client.isActive === false) throw new ErrorHandled('Client is not active', { status: 403, layer: 'DOMAIN' });
    // adding discounts and creating the purchase
    const finalProducts = applyDiscount(client, products);
    const id = uuidv4();

    const purchase = await createPurchase({ pk: 'purchase', id, dni, products: finalProducts })
    // getPoints over the finalPrice of the purchase
    const purchasePoints = getPurchasePoints(finalProducts);
    await updateClient(dni, { points: ((client.points || 0) + purchasePoints) })
    return {
        body: {
            status: 'success',
            id: purchase.Item.id
        },
        status: 201
    }


};