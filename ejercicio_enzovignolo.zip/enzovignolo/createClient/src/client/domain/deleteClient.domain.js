
const { ErrorHandled } = require("ebased/util/error");
const { DeleteClientValidation } = require("../schema/input/deleteClient.validation");

const { updateClient } = require("../services/updateClient.service");


module.exports = async (commandPayload, commandMeta) => {
    //validate input
    const inputDni = new DeleteClientValidation(commandPayload, commandMeta);
    //validate age if brithdate is to be updated
    console.log(inputDni.dni, inputDni);
    //save the client and emit event
    const deletedClient = await updateClient(inputDni.get().dni, { isActive: false });
    if (!deletedClient) throw new ErrorHandled('Client not found', { status: 404, layer: 'DOMAIN' })


    return {
        body: { status: 'sucess' },
        statusCode: 204
    }


};