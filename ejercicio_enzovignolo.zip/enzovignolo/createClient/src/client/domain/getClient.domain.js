
const { ErrorHandled } = require('ebased/util/error');
const { GetClientValidation } = require('../schema/input/getClient.validation');
const { getClient } = require('../services/getClient.service');







module.exports = async (commandPayload, commandMeta) => {
    //validate input
    new GetClientValidation(commandPayload, commandMeta);

    //save the client and emit event
    const { dni } = commandPayload;

    const client = await getClient(dni)
    if (!client) throw new ErrorHandled('Client not found', { status: 404, layer: 'DOMAIN' })


    return {
        body: client
    }


};