const { ErrorHandled } = require("ebased/util/error");
const { getAge } = require("../helper/getAge");
const { ClientCreatedEvent } = require("../schema/event/clientCreated");
const { ClientUpdatedEvent } = require("../schema/event/clientUpdated");
const { UpdateClientValidation } = require("../schema/input/updateClient.validation");
const { emitClientCreated } = require("../services/emitClientCreated");
const { updateClient } = require("../services/updateClient.service");






module.exports = async (commandPayload, commandMeta) => {
    //validate input
    const client = new UpdateClientValidation(commandPayload, commandMeta);
    //validate age if brithdate is to be updated

    const { birthdate } = commandPayload;
    if (birthdate) {

        const age = getAge(birthdate);
        if (age < 18 || age > 65) throw new ErrorHandled('Invalid age range', { status: 400, layer: 'DOMAIN' });
    }
    //save the client and emit event
    const { dni, ...toUpdateClient } = client.get();
    console.log('cliente que llega', client);
    const clientUpdated = await updateClient(dni, toUpdateClient);
    console.log('cliente actualizado', clientUpdated);
    if (!client) throw new ErrorHandled('Client not found', { status: 404, layer: 'DOMAIN' })
    await emitClientCreated(new ClientUpdatedEvent(clientUpdated, commandMeta));


    return {
        body: { status: 'success' }
    }


};