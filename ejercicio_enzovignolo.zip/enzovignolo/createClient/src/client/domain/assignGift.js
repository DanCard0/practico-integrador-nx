
const { getDateSeason } = require('../helper/getDateSeason');
const { AssignGiftValidation } = require('../schema/input/assignGiftValidation');
const { assignGift } = require('../services/assignGift.service');

const GIFTS = {
    "WINTER": "Sweater", "AUTUMN": "Buzo", "SUMMER": "Remera", "SPRING": "Camisa"
}
const selectGift = (birthdate) => {
    const date = new Date();
    const dateBirth = new Date(birthdate);
    dateBirth.setFullYear(date.getFullYear());
    const season = getDateSeason(dateBirth);

    return GIFTS[season];
}

module.exports = async (events, eventsMeta) => {
    //validate input
    const data = JSON.parse(events.Message)
    const client = new AssignGiftValidation(data, eventsMeta);
    //generate credit card
    const gift = selectGift(client.get().birthdate);
    //update the client 

    await assignGift(client.get().dni, gift);


    return {
        body: 'Gift assigned'
    }


};
