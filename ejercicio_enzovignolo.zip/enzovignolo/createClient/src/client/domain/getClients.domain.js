const { getClients } = require("../services/getClients.service");





module.exports = async (commandPayload, commandMeta) => {
    //llamar al servicio p obtener clientes
    const clients = await getClients();

    return {
        body: clients.Items
    }


};