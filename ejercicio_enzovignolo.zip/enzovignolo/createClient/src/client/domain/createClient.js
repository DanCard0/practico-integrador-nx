
const { CreateClientValidation } = require('../schema/input/createClientValidation');
const { getAge } = require('../helper/getAge');
const { ErrorHandled } = require('ebased/util/error');
const { emitClientCreated } = require('../services/emitClientCreated');
const { ClientCreatedEvent } = require('../schema/event/clientCreated');
const { createClient } = require('../services/createClient.service');





module.exports = async (commandPayload, commandMeta) => {
    //validate input
    const client = new CreateClientValidation(commandPayload, commandMeta);
    //validate age
    const { birthdate } = commandPayload;
    const age = getAge(birthdate);
    if (age < 18 || age > 65) throw new ErrorHandled('Invalid age range', { status: 400, layer: 'DOMAIN' });
    //save the client and emit event
    const isActive = client.get().isActive
    await createClient({ pk: 'client', ...client.get(), isActive: isActive == null ? true : isActive });
    await emitClientCreated(new ClientCreatedEvent(client.get(), commandMeta));


    return {
        body: { stauts: 'success', dni: client.get().dni },
        status: 201
    }


};