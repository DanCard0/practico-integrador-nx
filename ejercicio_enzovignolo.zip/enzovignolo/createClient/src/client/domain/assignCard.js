
const { ClientCreatedEvent } = require('../schema/event/clientCreated');
const { generateCreditCard } = require('../helper/generateCreditCard');
const { assignCard } = require('../services/assignCard.service');
const { AssignCardValidation } = require('../schema/input/assignCardValidation');





module.exports = async (events, eventsMeta) => {
    //validate input
    const data = JSON.parse(events.Message)
    const client = new AssignCardValidation(data, eventsMeta);
    //generate credit card
    const creditCard = generateCreditCard(client.get());
    //update the client 

    await assignCard(client.get().dni, creditCard);


    return {
        body: 'Card assigned'
    }


};

/**





exports.handler = async (event) => {

  
        //update user
        await updateClient(data, creditCard);
        console.log('[DB] Credit Card created')
        // return 200 if all is ok
        return {
            statusCode: 200,
            body: 'OK'
        }
    } catch (err) {
        console.log(err)
        return {
            statusCode: 500,
            body: 'error'
        }
    }
}


 */