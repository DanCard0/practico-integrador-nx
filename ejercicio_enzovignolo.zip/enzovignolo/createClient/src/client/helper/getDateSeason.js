exports.getDateSeason = (date) => {
    const todayDate = new Date()
    const seasons = {
        autumn: {
            start: new Date(todayDate.getFullYear(), 2, 21),
            end: new Date(todayDate.getFullYear(), 4, 20),
        },
        winter: {
            start: new Date(todayDate.getFullYear(), 4, 21),
            end: new Date(todayDate.getFullYear(), 8, 20),
        },
        summer: {
            start: new Date(todayDate.getFullYear() - 1, 11, 21),
            end: new Date(todayDate.getFullYear() + 1, 4, 20),
        },
        spring: {
            start: new Date(todayDate.getFullYear(), 8, 21),
            end: new Date(todayDate.getFullYear(), 11, 20),
        },

    }

    if (date > seasons.autumn.start && date < seasons.autumn.end) return 'AUTUMN'
    if (date > seasons.winter.start && date < seasons.winter.end) return 'WINTER'
    if (date > seasons.spring.start && date < seasons.spring.end) return 'SPRING'
    if (date > seasons.summer.start || date < seasons.summer.end) return 'SUMMER'

}