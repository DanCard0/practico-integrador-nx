const getAge = (birthdate) => {


    const ageMs = Date.now() - new Date(birthdate).getTime();
    return Math.abs(new Date(ageMs).getFullYear() - 1970);


}
module.exports = { getAge };