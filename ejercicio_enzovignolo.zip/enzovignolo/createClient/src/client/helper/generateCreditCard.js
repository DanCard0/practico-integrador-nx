const VALID_YEARS = 3;
const generateExpDate = (birthdate) => {
    const expYear = new Date().getFullYear() + VALID_YEARS;
    const dateBirth = new Date(birthdate);
    dateBirth.setFullYear(expYear)
    return dateBirth.getMonth() + '/' + dateBirth.getFullYear();
}
const generateSecCode = () => {
    return Math.floor(100 + Math.random() * 900).toString();
}

const generateCCNumber = () => Math.floor(100000000000 + Math.random() * 900000000000).toString();

const assignCCType = (birthdate) => {
    const ageMs = Date.now() - new Date(birthdate).getTime();
    const age = Math.abs(new Date(ageMs).getFullYear() - 1970);

    return age > 45 ? 'GOLD' : 'CLASSIC'
}

const generateCreditCard = (clientInfo) => {

    return {
        ccNumber: generateCCNumber(),
        ccExpiration: generateExpDate(clientInfo.birthdate),
        ccSecurity: generateSecCode(),
        ccType: assignCCType(clientInfo.birthdate) //classic | gold
    }
};

module.exports = { generateCreditCard };