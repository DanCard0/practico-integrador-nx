
const { DownstreamEvent } = require('ebased/schema/downstreamEvent');

class ClientCreatedEvent extends DownstreamEvent {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.CLIENT_CREATED',
            specversion: 'v1.0.0',
            payload: payload,
            meta: meta,
            schema: {
                strict: false,
                firstname: { type: String, required: true },
                lastname: { type: String, required: true },
                dni: { type: String, required: true },
                birthdate: { type: Date, required: true },
            },
        })
    }
}

module.exports = { ClientCreatedEvent };