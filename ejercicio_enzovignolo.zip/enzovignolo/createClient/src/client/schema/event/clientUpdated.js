
const { DownstreamEvent } = require('ebased/schema/downstreamEvent');

class ClientUpdatedEvent extends DownstreamEvent {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.CLIENT_UPDATED',
            specversion: 'v1.0.0',
            payload: payload,
            meta: meta,
            schema: {
                strict: false,
                firstname: { type: String },
                lastname: { type: String },
                dni: { type: String, required: true },
                birthdate: { type: Date, required: true },
            },
        })
    }
}

module.exports = { ClientUpdatedEvent };