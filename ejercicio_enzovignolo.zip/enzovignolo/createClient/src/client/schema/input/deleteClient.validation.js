const { InputValidation } = require('ebased/schema/inputValidation')
class DeleteClientValidation extends InputValidation {
    //Only dni should be required to update, others fields can be optional
    constructor(payload, meta) {
        super({
            type: 'CLIENT.DELETE_CLIENT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                dni: {
                    type: String, required: true, custom: (value) => {
                        if (value == 'null') return 'DNI can not be null';
                        return true
                    }
                },
            },
        })
    }
};

module.exports = { DeleteClientValidation };