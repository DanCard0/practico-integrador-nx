const { InputValidation } = require('ebased/schema/inputValidation')
class UpdateClientValidation extends InputValidation {
    //Only dni should be required to update, others fields can be optional
    constructor(payload, meta) {
        super({
            type: 'CLIENT.UPDATE_CLIENT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                dni: {
                    type: String, required: true, custom: (value) => {
                        if (value == 'null') return 'DNI can not be null';
                        return true
                    }
                },
                firstname: { type: String },
                lastname: { type: String },
                birthdate: { type: Date },
                isActive: { type: Boolean },


            },
        })
    }
};

module.exports = { UpdateClientValidation };