const { InputValidation } = require('ebased/schema/inputValidation')
class AssignGiftValidation extends InputValidation {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.ASSIGN_GIFT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                firstname: { type: String, required: true },
                lastname: { type: String, required: true },
                dni: { type: String, required: true },
                birthdate: { type: Date, required: true },
            },
        })
    }
};

module.exports = { AssignGiftValidation };