const { InputValidation } = require('ebased/schema/inputValidation')
class CreateClientValidation extends InputValidation {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.CREATE_CLIENT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                firstname: { type: String, required: true },
                lastname: { type: String, required: true },
                dni: { type: String, required: true },
                birthdate: { type: Date, required: true },
                isActive: { type: Boolean }

            },
        })
    }
};

module.exports = { CreateClientValidation };
/**
 * !dni || !firstname || !lastname || !birthdate
 */