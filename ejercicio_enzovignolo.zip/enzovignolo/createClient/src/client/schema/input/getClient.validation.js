const { InputValidation } = require('ebased/schema/inputValidation')
class GetClientValidation extends InputValidation {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.GET_CLIENT',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                dni: {
                    type: String, required: true, custom: (value) => {
                        if (value == 'null') return 'DNI can not be null';
                        return true
                    }
                },
            },
        })
    }
};

module.exports = { GetClientValidation };