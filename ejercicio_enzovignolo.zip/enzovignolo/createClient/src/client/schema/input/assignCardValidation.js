const { InputValidation } = require('ebased/schema/inputValidation')
class AssignCardValidation extends InputValidation {
    constructor(payload, meta) {
        super({
            type: 'CLIENT.ASSIGN_CARD',
            specversion: 'v1.0.0',
            source: meta.source,
            payload: payload,
            schema: {
                firstname: { type: String, required: true },
                lastname: { type: String, required: true },
                dni: { type: String, required: true },
                birthdate: { type: Date, required: true },
            },
        })
    }
};

module.exports = { AssignCardValidation };