const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');

const DYNAMO_TABLE = config.get('DB_TABLE')

const assignCard = async (clientDNI, creditCard) => {

    const params = {
        TableName: DYNAMO_TABLE,
        Key: {
            "pk": "client",
            "dni": clientDNI
        },
        ExpressionAttributeNames: { '#CC': 'creditCard' },
        ExpressionAttributeValues: {
            ":cc": {

                "number": creditCard.ccNumber,
                "expDate": creditCard.ccExpiration,
                "cvv": creditCard.ccSecurity,
                "type": creditCard.ccType

            }
        },
        UpdateExpression: 'set #CC = :cc'
    }
    await dynamo.updateItem(params);

}

module.exports = { assignCard };