const sns = require('ebased/service/downstream/sns');
const config = require('ebased/util/config');
const SNS_TOPIC = config.get('SNS_TOPIC');

const emitClientCreated = async (clientCreatedEvent) => {
    try {
        console.log('mandando evento', clientCreatedEvent.get());
        const { eventPayload, eventMeta } = clientCreatedEvent.get();
        console.log('payload y meta', eventPayload, eventMeta);
        const snsPublishParams = {
            TopicArn: SNS_TOPIC,
            Message: eventPayload,
        };
        await sns.publish(snsPublishParams, eventMeta);
    } catch (err) {
        console.log('err', err);
        throw err;
    }
}

module.exports = { emitClientCreated }