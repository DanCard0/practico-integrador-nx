const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');

const DYNAMO_TABLE = config.get('DB_TABLE')
const getClient = async (dni) => {
    const params = {
        TableName: DYNAMO_TABLE, Key: {
            "pk": 'client',
            "dni": dni
        }
    };
    const { Item } = await dynamo.getItem(params);

    return Item;
}

module.exports = { getClient };