const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');

const DYNAMO_TABLE = config.get('DB_TABLE')
const updateClient = async (dni, clientItem) => {
    let ExpressionAttributeNames = {};
    let ExpressionAttributeValues = {};
    let UpdateExpressionArr = [];
    Object.keys(clientItem).forEach((key) => {
        ExpressionAttributeNames[`#${key}`] = `${key}`;
        ExpressionAttributeValues[`:${key}`] = clientItem[key];
        UpdateExpressionArr.push(`#${key} = :${key}`);

    })
    const UpdateExpression = 'set ' + UpdateExpressionArr.join(',');

    const { Attributes } = await dynamo.updateItem({
        TableName: DYNAMO_TABLE,
        Key: {
            "pk": "client",
            "dni": dni
        },
        ExpressionAttributeNames,
        ExpressionAttributeValues,
        UpdateExpression,
        ReturnValues: 'ALL_NEW'
    });
    const { pk, ...updatedClient } = Attributes;
    console.log('atributos', Attributes);
    return Attributes
}

module.exports = { updateClient };

/**
 *  ExpressionAttributeNames: { '#CC': 'creditCard' },
        ExpressionAttributeValues: {
            ":cc": {

                "number": creditCard.ccNumber,
                "expDate": creditCard.ccExpiration,
                "cvv": creditCard.ccSecurity,
                "type": creditCard.ccType

            }
        },
        UpdateExpression: 'set #CC = :cc'
 */