const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');

const DYNAMO_TABLE = config.get('DB_TABLE')
const getClients = async () => {
    const params = {
        TableName: DYNAMO_TABLE, KeyConditionExpression: 'pk = :pk',
        ExpressionAttributeValues: { ':pk': 'client' },
        ProjectionExpression: 'dni,firstname,lastname,birthdate,isActive,gift,creditCard'
    }
    const clients = await dynamo.queryTable(params);
    return clients
}

module.exports = { getClients };
