const dynamo = require('ebased/service/storage/dynamo')
const config = require('ebased/util/config');
const { ErrorHandled } = require('ebased/util/error');

const DYNAMO_TABLE = config.get('DB_TABLE')
const createClient = async (clientItem) => {
    try {

        await dynamo.putItem({ TableName: DYNAMO_TABLE, Item: clientItem, ConditionExpression: 'attribute_not_exists(dni)' });
    } catch (err) {
        console.log(err.message);
        if (err.message === 'The conditional request failed') {

            throw new ErrorHandled('Duplicated DNI', { status: 400, layer: 'SERVICE' })
        }
        throw err;
    }
}

module.exports = { createClient };